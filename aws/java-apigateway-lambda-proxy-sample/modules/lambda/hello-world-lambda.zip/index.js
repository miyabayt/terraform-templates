'use strict';

module.exports.handler = function (event, context) {
    console.log("Hello world!");
};
